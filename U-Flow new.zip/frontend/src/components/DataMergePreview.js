import React from 'react';
import { Typography } from '@material-ui/core';

const DataMergePreview = ({ mergedData }) => {
    return (
        <div>
            <Typography variant="h6">Data Merge Preview</Typography>
            <div>
                {mergedData.map((item, index) => (
                    <div key={index}>
                        <img src={item.image} alt={`Preview ${index}`} style={{ maxWidth: '100%' }} />
                        <div>
                            {item.textData.map((text, textIndex) => (
                                <div key={textIndex} style={{ color: text.color, fontFamily: text.fontFamily, fontSize: text.fontSize, outline: text.outline }}>
                                    {text.content}
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default DataMergePreview;