import React from 'react';
import { TextField, MenuItem } from '@material-ui/core';
import { useTranslation } from 'react-i18next';

const TextSettings = ({ textColor, setTextColor, outlineColor, setOutlineColor, fontFamily, setFontFamily, fontSize, setFontSize }) => {
    const { t } = useTranslation();

    return (
        <div>
            <TextField
                label={t('Text Color')}
                type="color"
                value={textColor}
                onChange={(e) => setTextColor(e.target.value)}
                fullWidth
                margin="normal"
            />
            <TextField
                label={t('Outline Color')}
                type="color"
                value={outlineColor}
                onChange={(e) => setOutlineColor(e.target.value)}
                fullWidth
                margin="normal"
            />
            <TextField
                label={t('Font Family')}
                value={fontFamily}
                onChange={(e) => setFontFamily(e.target.value)}
                select
                fullWidth
                margin="normal"
            >
                <MenuItem value="Arial">Arial</MenuItem>
                <MenuItem value="Times New Roman">Times New Roman</MenuItem>
                <MenuItem value="Courier New">Courier New</MenuItem>
                <MenuItem value="Verdana">Verdana</MenuItem>
                {/* Add more font options here */}
            </TextField>
            <TextField
                label={t('Font Size')}
                type="number"
                value={fontSize}
                onChange={(e) => setFontSize(e.target.value)}
                fullWidth
                margin="normal"
            />
        </div>
    );
};

export default TextSettings;