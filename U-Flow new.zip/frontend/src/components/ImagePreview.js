import React from 'react';

const ImagePreview = ({ imagePreview }) => {
    return (
        <div>
            {imagePreview && <img src={imagePreview} alt="Preview" style={{ maxWidth: '100%' }} />}
        </div>
    );
};

export default ImagePreview;