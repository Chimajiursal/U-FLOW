import React, { useState } from 'react';
import { Typography } from '@material-ui/core';

const ImageUploader = ({ onUpload }) => {
    const [imagePreview, setImagePreview] = useState(null);

    const handleImageUpload = (event) => {
        const file = event.target.files[0];

        const reader = new FileReader();
        reader.onload = (e) => {
            setImagePreview(e.target.result);
            onUpload(e.target.result);
        };
        reader.readAsDataURL(file);
    };

    return (
        <div>
            <Typography variant="h6">Upload Image File</Typography>
            <input type="file" accept="image/*" onChange={handleImageUpload} />
            {imagePreview && (
                <div>
                    <Typography variant="h6">Image Preview</Typography>
                    <img src={imagePreview} alt="Preview" style={{ maxWidth: '100%' }} />
                </div>
            )}
        </div>
    );
};

export default ImageUploader;