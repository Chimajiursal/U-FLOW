import React from 'react';
import { Typography } from '@material-ui/core';

const ExcelPreview = ({ excelPreview }) => {
    return (
        <div>
            <Typography variant="h6">Excel Preview</Typography>
            <div>
                {excelPreview.map((row, rowIndex) => (
                    <div key={rowIndex}>
                        {row.map((cell, cellIndex) => (
                            <span key={cellIndex}>{cell} </span>
                        ))}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ExcelPreview;