import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

i18n.use(initReactI18next).init({
    resources: {
        en: {
            translation: {
                "Upload Files": "Upload Files",
                "Excel Preview": "Excel Preview",
                "Text Color": "Text Color",
                "Outline Color": "Outline Color",
                "Font Family": "Font Family",
                "Font Size": "Font Size",
                "Merge and Export": "Merge and Export",
                "Preview Merge": "Preview Merge",
            }
        },
        hi: {
            translation: {
                "Upload Files": "फ़ाइल अपलोड करें",
                "Excel Preview": "एक्सेल पूर्वावलोकन",
                "Text Color": "पाठ का रंग",
                "Outline Color": "रूपरेखा रंग",
                "Font Family": "फ़ॉन्ट परिवार",
                "Font Size": "फ़ॉन्ट का आकार",
                "Merge and Export": "मर्ज करें और निर्यात करें",
                "Preview Merge": "प्रीव्यू मर्ज",
            }
        },
        ta: {
            translation: {
                "Upload Files": "கோப்புகளை பதிவேற்றவும்",
                "Excel Preview": "எக்செல் முன்னோட்டம்",
                "Text Color": "உரை நிறம்",
                "Outline Color": "அடிக்கோடு நிறம்",
                "Font Family": "எழுத்துரு குடும்பம்",
                "Font Size": "எழுத்துரு அளவு",
                "Merge and Export": "மர்ஜ் மற்றும் ஏற்றுமதி",
                "Preview Merge": "முன்னோட்டத்தை மெர்ஜ் செய்க",
            }
        },
        te: {
            translation: {
                "Upload Files": "ఫైల్‌లను అప్‌లోడ్ చేయండి",
                "Excel Preview": "ఎక్సెల్ ప్రీవ్యూ",
                "Text Color": "టెక్స్ట్ కలర్",
                "Outline Color": "అవుట్‌లైన్ కలర్",
                "Font Family": "ఫాంట్ ఫ్యామిలీ",
                "Font Size": "ఫాంట్ సైజ్",
                "Merge and Export": "మర్జ్ మరియు ఎగుమతి",
                "Preview Merge": "మర్జ్ ప్రీవ్యూ",
            }
        },
        bn: {
            translation: {
                "Upload Files": "ফাইল আপলোড করুন",
                "Excel Preview": "এক্সেল প্রিভিউ",
                "Text Color": "টেক্সট রঙ",
                "Outline Color": "আউটলাইন রঙ",
                "Font Family": "ফন্ট পরিবার",
                "Font Size": "ফন্ট আকার",
                "Merge and Export": "মার্জ এবং এক্সপোর্ট",
                "Preview Merge": "প্রিভিউ মার্জ",
            }
        },
        // Add more languages as needed
    },
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
        escapeValue: false
    }
});

export default i18n;