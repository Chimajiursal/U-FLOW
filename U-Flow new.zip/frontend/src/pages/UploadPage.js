import React, { useState } from 'react';
import { Button, Typography, MenuItem, Select } from '@material-ui/core';
import { useTranslation } from 'react-i18next';
import ExcelUploader from '../components/ExcelUploader';
import ImageUploader from '../components/ImageUploader';
import TextSettings from '../components/TextSettings';
import DataMergePreview from '../components/DataMergePreview';
import { saveAs } from 'file-saver';

const UploadPage = () => {
    const { t, i18n } = useTranslation();
    const [textColor, setTextColor] = useState('#000000');
    const [outlineColor, setOutlineColor] = useState('#000000');
    const [fontFamily, setFontFamily] = useState('Arial');
    const [fontSize, setFontSize] = useState(16);
    const [language, setLanguage] = useState('en');
    const [excelData, setExcelData] = useState([]);
    const [imageData, setImageData] = useState(null);
    const [mergedData, setMergedData] = useState([]);
    const [mergedImage, setMergedImage] = useState(null);

    const handleLanguageChange = (event) => {
        const newLanguage = event.target.value;
        setLanguage(newLanguage);
        i18n.changeLanguage(newLanguage);
    };

    const handleExcelUpload = (data) => {
        setExcelData(data);
    };

    const handleImageUpload = (data) => {
        setImageData(data);
    };

    const handleMergeAndPreview = () => {
        const merged = excelData.map((row) => ({
            image: imageData,
            textData: row.map((cell, index) => ({
                content: cell,
                color: textColor,
                fontFamily: fontFamily,
                fontSize: `${fontSize}px`,
                outline: `1px solid ${outlineColor}`
            }))
        }));
        setMergedData(merged);
    };

    const handleMergeAndExport = () => {
        // Logic to merge Excel data with the image and create the final image
        // For demonstration purposes, we'll assume the merged image is created and stored in mergedImage
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();
        img.src = imageData;
        img.onload = () => {
            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0);

            excelData.forEach((row, rowIndex) => {
                row.forEach((cell, cellIndex) => {
                    ctx.fillStyle = textColor;
                    ctx.font = `${fontSize}px ${fontFamily}`;
                    ctx.strokeStyle = outlineColor;
                    ctx.lineWidth = 1;
                    ctx.strokeText(cell, 10 + cellIndex * 100, 30 + rowIndex * 30); // Example positions
                    ctx.fillText(cell, 10 + cellIndex * 100, 30 + rowIndex * 30);
                });
            });

            canvas.toBlob((blob) => {
                setMergedImage(blob);
                saveAs(blob, 'merged_image.png'); // Automatically download the image
            });
        };
    };

    return (
        <div>
            <Typography variant="h4">{t('Upload Files')}</Typography>
            <Select
                value={language}
                onChange={handleLanguageChange}
                displayEmpty
                fullWidth
                margin="normal"
            >
                <MenuItem value="en">English</MenuItem>
                <MenuItem value="hi">हिंदी</MenuItem>
                <MenuItem value="ta">தமிழ்</MenuItem>
                <MenuItem value="te">తెలుగు</MenuItem>
                <MenuItem value="bn">বাংলা</MenuItem>
                {/* Add more language options here */}
            </Select>
            <ExcelUploader onUpload={handleExcelUpload} />
            <ImageUploader onUpload={handleImageUpload} />
            <TextSettings
                textColor={textColor}
                setTextColor={setTextColor}
                outlineColor={outlineColor}
                setOutlineColor={setOutlineColor}
                fontFamily={fontFamily}
                setFontFamily={setFontFamily}
                fontSize={fontSize}
                setFontSize={setFontSize}
            />
            <Button variant="contained" color="primary" onClick={handleMergeAndPreview}>
                {t('Preview Merge')}
            </Button>
            <DataMergePreview mergedData={mergedData} />
            <Button variant="contained" color="primary" onClick={handleMergeAndExport}>
                {t('Merge and Export')}
            </Button>
        </div>
    );
};

export default UploadPage;