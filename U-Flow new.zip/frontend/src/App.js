import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import UploadPage from './pages/UploadPage';
import './i18n/i18n';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/" component={UploadPage} />
            </Switch>
        </Router>
    );
}

export default App;