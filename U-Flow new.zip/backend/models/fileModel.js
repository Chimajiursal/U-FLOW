const mongoose = require('mongoose');

const fileSchema = new mongoose.Schema({
    fileName: String,
    fileType: String,
    fileData: Buffer,
    uploadDate: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('File', fileSchema);