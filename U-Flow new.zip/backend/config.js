module.exports = {
    mongoURI: 'your-mongodb-connection-string'
};