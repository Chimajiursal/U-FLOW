const uploadExcel = (req, res) => {
    // Logic to handle Excel file upload
    res.send('Excel file uploaded');
};

const uploadImage = (req, res) => {
    // Logic to handle image file upload
    res.send('Image file uploaded');
};

const mergeData = (req, res) => {
    // Logic to merge Excel data with the image
    res.send('Data merged and exported');
};

module.exports = {
    uploadExcel,
    uploadImage,
    mergeData
};