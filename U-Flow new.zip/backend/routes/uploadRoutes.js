const express = require('express');
const { uploadExcel, uploadImage, mergeData } = require('../controllers/uploadController');
const router = express.Router();

router.post('/excel', uploadExcel);
router.post('/image', uploadImage);
router.post('/merge', mergeData);

module.exports = router;