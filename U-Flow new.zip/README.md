# Web-based Application

This project is a web-based application that allows users to upload Excel files and images, customize text settings, and merge Excel data with the uploaded image. The final merged image can be exported in the specified format.

## Features

- Upload Excel files and images
- Preview uploaded files
- Customize text settings (color, outline, font, size)
- Support for multiple languages
- Merge Excel data with the uploaded image
- Export the final merged image

## Setup

### Backend

1. Navigate to the backend directory:
    ```bash
    cd backend
    ```

2. Install dependencies:
    ```bash
    npm install
    ```

3. Create a `config.js` file with your MongoDB connection string:
    ```javascript
    module.exports = {
        mongoURI: 'your-mongodb-connection-string'
    };
    ```

4. Start the server:
    ```bash
    npm start
    ```

### Frontend

1. Navigate to the frontend directory:
    ```bash
    cd frontend
    ```

2. Install dependencies:
    ```bash
    npm install
    ```

3. Start the development server:
    ```bash
    npm start
    ```

## Deployment

To deploy the application, you can use a cloud service like AWS, Azure, or Heroku. Set up a CI/CD pipeline to automate the deployment process.

## Contributing

Contributions are welcome! Please fork the repository and submit a pull request.

## License

This project is licensed under the MIT License.