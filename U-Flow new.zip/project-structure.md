```
/web-app
├── /backend
│   ├── /controllers
│   │   └── uploadController.js
│   ├── /models
│   │   └── fileModel.js
│   ├── /routes
│   │   └── uploadRoutes.js
│   ├── app.js
│   ├── config.js
│   └── package.json
├── /frontend
│   ├── /public
│   ├── /src
│   │   ├── /components
│   │   ├── /i18n
│   │   │   └── i18n.js
│   │   ├── /pages
│   │   │   └── UploadPage.js
│   │   ├── App.js
│   │   ├── index.js
│   │   └── package.json
├── .gitignore
└── README.md
```